﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IceCream.Components;
using IceCream.Attributes;
using Microsoft.Xna.Framework;
using IceCream;
using Microsoft.Xna.Framework.Graphics;

namespace $rootnamespace$
{
    [IceComponentAttribute("$safeitemname$")]
    public class $safeitemname$:IceComponent
    {
        
        public $safeitemname$()
        {
        }
        public override void OnRegister()
        {
            Enabled = true;
        }

        public override void Update(float elapsedTime)
        {
        
        }
        
    }
}
